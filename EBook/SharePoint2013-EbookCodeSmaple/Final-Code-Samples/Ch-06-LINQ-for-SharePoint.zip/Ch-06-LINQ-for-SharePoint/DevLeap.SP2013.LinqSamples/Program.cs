﻿using Microsoft.SharePoint.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace DevLeap.SP2013.LinqSamples
{
    class Program
    {
        static void Main(string[] args)
        {
            QueryInvoices();
            QueryContactsJoinedWithInvoices();
            DeferredLoadingSample();
            UnsupportedJoinIntoSampleQuery();
            UpdateContactItem();
            InsertContactItem();
            DeleteContactItem(true);
            ConcurrencyManagement();
            ShowIdentityManagementBehavior();
            EntitySerialization();
        }

        // Listing 6-6
        static void QueryInvoices()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                var query = from i in spContext.Invoices
                            where i.DocumentCreatedBy == @"i:0#.w|sp2013\administrator"
                            select i.Title;

                foreach (var i in query)
                {
                    Console.WriteLine(i);
                }
            }
        }

        // Listing 6-8
        static void QueryContactsJoinedWithInvoices()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                var query = from c in spContext.DevLeapContacts
                            join i in spContext.Invoices on c.Id equals i.DevLeapContact.Id
                            select new { c.ContactID, c.Title, InvoiceTitle = i.Title };

                foreach (var i in query)
                {
                    Console.WriteLine(i);
                }
            }
        }

        // Listing 6-9
        static void DeferredLoadingSample()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.DeferredLoadingEnabled = true;
                spContext.Log = Console.Out;

                var query = from c in spContext.DevLeapContacts
                            select c;

                foreach (var c in query)
                {
                    Console.WriteLine(c.Title);
                    foreach (var i in c.DevLeapInvoice)
                    {
                        Console.WriteLine(i.Title);
                    }
                }
            }
        }

        // Listing 6-10
        static void UnsupportedJoinIntoSampleQuery()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.DeferredLoadingEnabled = false;
                spContext.Log = Console.Out;

                var query = from c in spContext.DevLeapContacts
                            join i in spContext.Invoices on c.Id equals i.DevLeapContact.Id
                            into invoices
                            select new { c.Id, c.Title, Invoiced = invoices };

                foreach (var c in query)
                {
                    Console.WriteLine(c);
                }
            }
        }

        // Listing 6-11
        static void UpdateContactItem()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                var contact = (from c in spContext.DevLeapContacts
                               where c.ContactID == "PP001"
                               select c).FirstOrDefault();

                // Let's see if we found the target contact
                if (contact != null)
                {
                    Console.WriteLine(((ITrackEntityState)contact).EntityState);
                    contact.Country = Country.Italy;
                    Console.WriteLine(((ITrackEntityState)contact).EntityState);

                    spContext.SubmitChanges();
                    Console.WriteLine(((ITrackEntityState)contact).EntityState);
                }
            }
        }

        // Listing 6-12
        static void InsertContactItem()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                DevLeapCustomer newCustomer = new DevLeapCustomer
                {
                    Title = "Andrea Pialorsi",
                    ContactID = "AP001",
                    CompanyName = "DevLeap",
                    Country = Country.Italy,
                    CustomerLevel = CustomerLevel.LevelA,
                };

                spContext.DevLeapContacts.InsertOnSubmit(newCustomer);

                spContext.SubmitChanges();
            }
        }

        // Listing 6-13
        static void DeleteContactItem(Boolean recycle)
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                var contact = (from c in spContext.DevLeapContacts
                               where c.ContactID == "AP001"
                               select c).FirstOrDefault();

                // Let's see if we found the target contact
                if (contact != null)
                {
                    if (recycle)
                    {
                        spContext.DevLeapContacts.RecycleOnSubmit(contact);
                    }
                    else
                    {
                        spContext.DevLeapContacts.DeleteOnSubmit(contact);
                    }

                    spContext.SubmitChanges();
                }
            }
        }

        // Listing 6-14
        static void ConcurrencyManagement()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.Log = Console.Out;

                var contacts = from c in spContext.DevLeapContacts
                               where c.Country == Country.Italy
                               select c;

                String conflictingItemID = contacts.FirstOrDefault().ContactID;

                foreach (var item in contacts)
                {
                    item.CompanyName += String.Format(" - Changed on {0}", DateTime.Now);
                }

                // Before submitting changes, the code simulate concurrency
                // changing one of the items from another DataContext
                using (DevbookDataContext spContextOther =
                    new DevbookDataContext("http://devbook.sp2013.local/"))
                {
                    var conflictingItem = (from c in spContextOther.DevLeapContacts
                                           where c.ContactID == conflictingItemID
                                           select c).FirstOrDefault();

                    conflictingItem.Country = Country.USA;
                    spContextOther.SubmitChanges();
                }

                try
                {
                    spContext.SubmitChanges(ConflictMode.ContinueOnConflict);
                }
                catch (ChangeConflictException ex)
                {
                    Console.WriteLine(ex.Message);

                    // Browse for conflicting items
                    foreach (var conflict in spContext.ChangeConflicts)
                    {
                        // Check if the item has been deleted by
                        // someone else
                        if (conflict.IsDeleted)
                        {
                            Console.WriteLine("Unfortunately the item has been deleted, so your changes cannot be submitted!");
                        }
                        else
                        {
                            // Retrieve a typed reference to the conflicting item
                            DevLeapContact contact = conflict.Object as DevLeapContact;

                            // If the item is a DevLeapContact
                            if (contact != null)
                            {
                                Console.WriteLine("Contact with ID {0} is in conflict!", contact.ContactID);

                                // Browse for conflicting members
                                foreach (var member in conflict.MemberConflicts)
                                {
                                    Console.WriteLine("Member {0} is in conflict.\n\tCurrent Value: {1}\n\tOriginal Value: {2}\n\tDatabase Value: {3}",
                                        member.Member.Name,
                                        member.CurrentValue,
                                        member.OriginalValue,
                                        member.DatabaseValue);
                                }

                                Console.WriteLine("Make your choice: Override Database Value (Y) or Skip your Current Values (N)?");
                                String choice = Console.ReadLine().ToLower();

                                switch (choice)
                                {
                                    case "y":
                                    case "yes":
                                        conflict.Resolve(RefreshMode.KeepChanges, true);
                                        break;
                                    case "n":
                                    case "no":
                                        conflict.Resolve(RefreshMode.OverwriteCurrentValues, true);
                                        break;
                                    default:
                                        break;
                                }
                            }
                        }
                    }
                    spContext.SubmitChanges();
                }
            }
        }

        // Listing 6-15
        static void ShowIdentityManagementBehavior()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                // spContext.Log = Console.Out;

                var contacts = from c in spContext.DevLeapContacts
                               where c.CompanyName.Contains("DevLeap")
                               select c;

                // Change the Country property of the first contact
                contacts.FirstOrDefault().Country = Country.USA;

                // Show all the retrieved contacts
                foreach (var c in contacts)
                {
                    Console.WriteLine("Customer with ID {0} has a Country value of {1}",
                        c.ContactID, c.Country);
                }

                Console.WriteLine("------------------");

                // Retrieve the same contacts with another LINQ query
                var otherContacts = from c in spContext.DevLeapContacts
                                    where c.CompanyName.Contains("DevLeap")
                                    select c;

                // Show all the newly retrieved contacts
                foreach (var c in otherContacts)
                {
                    Console.WriteLine("Customer with ID {0} has a Country value of {1}",
                        c.ContactID, c.Country);
                }

                // Check if the two first contacts instances are the same contact
                Console.WriteLine("Do the contacts have the same HashCode? {0}",
                    contacts.FirstOrDefault().GetHashCode() ==
                        otherContacts.FirstOrDefault().GetHashCode());
            }
        }

        // Listing 6-16
        static void EntitySerialization()
        {
            using (DevbookDataContext spContext = new DevbookDataContext("http://devbook.sp2013.local/"))
            {
                spContext.DeferredLoadingEnabled = false;

                var contact = (from c in spContext.DevLeapContacts
                               where c.ContactID == "PP001"
                               select c).FirstOrDefault();

                // Let's see if we found the target contact
                if (contact != null)
                {
                    DataContractSerializer dcs = new DataContractSerializer(typeof(DevLeapContact),
                        new Type[] { typeof(DevLeapCustomer), typeof(DevLeapSupplier) });

                    try
                    {
                        using (XmlWriter xw = XmlWriter.Create(Console.Out))
                        {
                            dcs.WriteObject(xw, contact);
                            xw.Flush();
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                }
            }
        }
    }
}
