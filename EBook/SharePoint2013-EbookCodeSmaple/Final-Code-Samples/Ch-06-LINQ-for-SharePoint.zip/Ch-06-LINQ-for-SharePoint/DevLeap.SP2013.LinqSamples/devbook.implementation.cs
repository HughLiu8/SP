﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.SP2013.LinqSamples
{
    internal partial class DevLeapCustomer : ICustomMapping
    {
        private String _address;

        public String Address
        {
            get { return (this._address); }
            set { this._address = value; }
        }

        [CustomMapping(Columns = new String[] { "*" })]
        public void MapFrom(object listItem)
        {
            SPListItem item = listItem as SPListItem;
            try
            {
                if (item != null)
                {
                    this.Address = item["address"].ToString();
                }
            }
            catch (ArgumentException)
            { 
                // The mapping doesn't work
            }
        }

        public void MapTo(object listItem)
        {
            SPListItem item = listItem as SPListItem;
            try
            {
                if (item != null)
                {
                    item["address"] = this.Address;
                }
            }
            catch (ArgumentException)
            {
                // The mapping doesn't work
            }
        }

        public void Resolve(RefreshMode mode, object originalListItem, object databaseListItem)
        {
            // Code omitted for the sake of brevity
        }
    }
}
