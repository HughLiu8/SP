﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Client;

namespace DevLeap.SP2013.CSOM
{
    class Program
    {
        static void Main(string[] args)
        {
            //BrowseForContacts();
            //BrowseForContactsWithExtraFields();
            //BrowseForContactsWithExtraFieldsNoStressingServer();
            //BrowseForContactsProjectingFieldsWithCAML();
            //BrowseForContactsProjectingFields();
            //BrowseForContactsWithLINQ();
            //UseClientObjectType();
            ////UseClientValueObjectTypeWrongly();
            ////UseClientValueObjectTypeCorrectly();
            CreateNewList();
            CreateNewListItem();
            UpdateListItem();
            //TryAddItemToList();
            //UseExceptionHandlingScopeOutline();
            //UseExceptionHandlingScope();
            //DeleteListItem();
            //QueryItemsWithPaging();
            //CreateNewDocumentLibrary();
            //UploadFileInDocumentLibrary();
            //DownloadFileFromDocumentLibrary();
            //CheckInAndCheckOut();
            //CheckInAndCheckOut();
            //MoveOrCopyFile();
        }

        // Listing 7-1
        static void BrowseForContacts()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");
            //ctx.AuthenticationMode = ClientAuthenticationMode.FormsAuthentication;
            //FormsAuthenticationLoginInfo loginInfo = new FormsAuthenticationLoginInfo { 
            //    LoginName = "UserLoginName",
            //    Password = "HereYourPassword",
            //};
            //ctx.FormsAuthenticationLoginInfo = loginInfo;

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View/>";
            ListItemCollection allContacts = list.GetItems(query);
            ctx.Load(allContacts);

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in allContacts)
            {
                Console.WriteLine("Id: {0} - Fullname: {1} - Company: {2} - Country: {3}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCompanyName"],
                    listItem["DevLeapCountry"]
                    );

                // Console.WriteLine(listItem.DisplayName);
            }
        }

        // Listing 7-2
        static void BrowseForContactsWithExtraFields()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View/>";
            ListItemCollection allContacts = list.GetItems(query);
            ctx.Load(allContacts);

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in allContacts)
            {
                ctx.Load(listItem,
                    item => item.DisplayName,
                    item => item.RoleAssignments);

                ctx.ExecuteQuery();

                Console.WriteLine("Id: {0} - Fullname: {1} - Company: {2} - Country: {3}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCompanyName"],
                    listItem["DevLeapCountry"]
                    );

                Console.WriteLine(listItem.DisplayName);
            }
        }

        // Listing 7-3
        static void BrowseForContactsWithExtraFieldsNoStressingServer()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View/>";
            ListItemCollection allContacts = list.GetItems(query);
            ctx.Load(allContacts);

            // Define the extra properties to include in default properties
            ctx.Load(allContacts,
                items => items.IncludeWithDefaultProperties(
                    item => item.DisplayName,
                    item => item.RoleAssignments
                    ));

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in allContacts)
            {
                Console.WriteLine("Id: {0} - Fullname: {1} - Company: {2} - Country: {3}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCompanyName"],
                    listItem["DevLeapCountry"]
                    );

                Console.WriteLine(listItem.DisplayName);
            }
        }

        // Listing 7-4
        static void BrowseForContactsProjectingFieldsWithCAML()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View><ViewFields><FieldRef Name='DevLeapContactID'/><FieldRef Name='Title'/><FieldRef Name='DevLeapCountry'/></ViewFields></View>";
            ListItemCollection allContacts = list.GetItems(query);
            ctx.Load(allContacts);

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in allContacts)
            {
                Console.WriteLine("Id: {0} - Fullname: {1} - Country: {2}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCountry"]
                    );
            }
        }

        // Listing 7-5
        static void BrowseForContactsProjectingFields()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View />";
            ListItemCollection allContacts = list.GetItems(query);

            // Define the fields to include in the output
            ctx.Load(allContacts,
                items => items.Include(
                    item => item["DevLeapContactID"],
                    item => item["Title"],
                    item => item["DevLeapCountry"]
                    ));

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in allContacts)
            {
                Console.WriteLine("Id: {0} - Fullname: {1} - Country: {2}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCountry"]
                    );
            }
        }

        // Listing 7-6
        static void BrowseForContactsWithLINQ()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the current Site Collection
            Site site = ctx.Site;
            ctx.Load(site);

            // Prepare a reference to the current Web Site
            Web web = site.RootWeb;
            ctx.Load(web);

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = web.Lists.GetByTitle("DevLeap Contacts");
            ctx.Load(list);

            // Execute the prepared commands against the target ClientContext
            ctx.ExecuteQuery();

            // Show the title of the list just retrieved
            Console.WriteLine(list.Title);

            // Prepare a query for all items in the list
            CamlQuery query = new CamlQuery();
            query.ViewXml = "<View />";
            ListItemCollection allContacts = list.GetItems(query);

            var linqQuery =
                from c in allContacts
                where (String)c["DevLeapCountry"] == "Italy"
                select c;

            var linqQueryResult = ctx.LoadQuery(linqQuery);

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQuery();

            // Browse the result
            Console.WriteLine("\nContacts");
            foreach (ListItem listItem in linqQueryResult)
            {
                Console.WriteLine("Id: {0} - Fullname: {1} - Country: {2}",
                    listItem["DevLeapContactID"],
                    listItem["Title"],
                    listItem["DevLeapCountry"]
                    );
            }
        }

        // Listing 7-7
        static void UseClientObjectType()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the target list, we can directly reference
            // the property ctx.Web.Lists because both Web and Lists are of types
            // inherited from ClientObject
            List list = ctx.Web.Lists.GetByTitle("DevLeap Contacts");

            // Retrieve the title of the list
            ctx.Load(list,
                l => l.Title);

            // Execute the query
            ctx.ExecuteQuery();

            // Show the result
            Console.WriteLine(list.Title);
        }

        // Listing 7-8
        static void UseClientValueObjectTypeWrongly()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Prepare a reference to the target list
            // Here you will get a PropertyOrFieldNotInitializedException 
            // when accessing the Title property of the current web site
            List list = ctx.Web.Lists.GetByTitle(ctx.Web.Title);

            // Retrieve the title of the list
            ctx.Load(list,
                l => l.Title);

            // Execute the query
            ctx.ExecuteQuery();

            // Show the result
            Console.WriteLine(list.Title);
        }

        // Listing 7-9
        static void UseClientValueObjectTypeCorrectly()
        {
            // Open the current ClientContext
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            // Retrieve the title of the web site
            Web web = ctx.Web;
            ctx.Load(web,
                w => w.Title);

            // Execute the first query
            ctx.ExecuteQuery();

            // Prepare a reference to the target list
            List list = ctx.Web.Lists.GetByTitle(web.Title);

            // Retrieve the title of the list
            ctx.Load(list,
                l => l.Title);

            // Execute the second query
            ctx.ExecuteQuery();

            // Show the result
            Console.WriteLine(list.Title);
        }

        // Listing 7-15
        static void CreateNewList()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            ListCreationInformation lci = new ListCreationInformation();
            lci.Title = "Contacts CSOM";
            lci.Description = "Contacts Created by Client Side Object Model";
            lci.TemplateType = (Int32)ListTemplateType.Contacts;
            lci.QuickLaunchOption = QuickLaunchOptions.On;

            List newList = ctx.Web.Lists.Add(lci);
            ctx.ExecuteQuery();
        }

        // Listing 7-16
        static void CreateNewListItem()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");

            ListItem item = contactsList.AddItem(new ListItemCreationInformation());
            item["Title"] = "Paolo Pialorsi";
            item["Email"] = "paolo@devleap.com";
            item["Company"] = "DevLeap";
            item.Update();

            ctx.ExecuteQuery();
        }

        // Listing 7-17
        static void UpdateListItem()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");
            ListItem itemToUpdate = contactsList.GetItemById(1);

            itemToUpdate["Company"] = "DevLeap - Changed!";
            itemToUpdate.Update();

            Console.WriteLine("Press ENTER to confirm changes");
            Console.ReadLine();

            ctx.ExecuteQuery();
        }

        // Listing 7-18
        static void TryAddItemToList()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List contactsList = null;

            try
            {
                contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");
                ctx.Load(contactsList);
                ctx.ExecuteQuery();
            }
            catch (ServerException)
            {
                ListCreationInformation lci = new ListCreationInformation();
                lci.Title = "Contacts CSOM";
                lci.Description = "Contacts Created by Client Side Object Model";
                lci.TemplateType = (Int32)ListTemplateType.Contacts;
                lci.QuickLaunchOption = QuickLaunchOptions.On;

                contactsList = ctx.Web.Lists.Add(lci);
                ctx.ExecuteQuery();
            }
            finally
            {
                ListItem item = contactsList.AddItem(new ListItemCreationInformation());
                item["Title"] = "Paolo Pialorsi";
                item["Email"] = "paolo@devleap.com";
                item["Company"] = "DevLeap";
                item.Update();

                ctx.ExecuteQuery();
            }
        }

        // Listing 7-19
        static void UseExceptionHandlingScopeOutline()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            ExceptionHandlingScope scope = new ExceptionHandlingScope(ctx);

            using (scope.StartScope())
            {
                using (scope.StartTry())
                {
                    // Try to do something on the server-side
                }

                using (scope.StartCatch())
                {
                    // Do something else in case of failure
                    // on the server-side
                }

                using (scope.StartFinally())
                {
                    // Execute this code, whatever is the result
                    // of previous code blocks
                }
            }

            // Now invoke the server, just one time
            ctx.ExecuteQuery();
        }

        // Listing 7-20
        static void UseExceptionHandlingScope()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            ExceptionHandlingScope scope = new ExceptionHandlingScope(ctx);

            using (scope.StartScope())
            {
                using (scope.StartTry())
                {
                    // Try to reference the target list
                    List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");
                }
                using (scope.StartCatch())
                {
                    // Create the list, in case it doesn’t exist
                    ListCreationInformation lci = new ListCreationInformation();
                    lci.Title = "Contacts CSOM";
                    lci.Description = "Contacts Created by Client Side Object Model";
                    lci.TemplateType = (Int32)ListTemplateType.Contacts;
                    lci.QuickLaunchOption = QuickLaunchOptions.On;

                    List contactsList = ctx.Web.Lists.Add(lci);
                }
                using (scope.StartFinally())
                {
                    // Add the ListItem, whether the list has just been created
                    // or was already existing
                    List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");

                    ListItem item = contactsList.AddItem(new ListItemCreationInformation());
                    item["Title"] = "Paolo Pialorsi";
                    item["Email"] = "paolo@devleap.com";
                    item["Company"] = "DevLeap";
                    item.Update();
                }
            }

            // Now invoke the server, just one time
            ctx.ExecuteQuery();
        }

        // Listing 7-21
        static void DeleteListItem()
        {
            //CreateNewList();
            //CreateNewListItem();

            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");
            ListItem itemToDelete = contactsList.GetItemById(1);

            itemToDelete.DeleteObject();
            ctx.ExecuteQuery();
        }

        // Listing 7-22
        static void QueryItemsWithPaging()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List contactsList = ctx.Web.Lists.GetByTitle("Contacts CSOM");

            // Populate the list with trivial data
            for (Int32 c = 0; c < 50; c++)
            {
                ListItem item = contactsList.AddItem(new ListItemCreationInformation());
                item["Title"] = String.Format("Contact {0:00}", c);
                item["Email"] = String.Format("email_{0:00}@domain.com", c);
                item["Company"] = String.Format("Company {0:00}", c);
                item.Update();
            }

            ctx.ExecuteQuery();

            ListItemCollectionPosition itemPosition = null;
            Int32 currentPage = 0;

            do
            {
                CamlQuery query = new CamlQuery();
                query.ListItemCollectionPosition = itemPosition;
                query.ViewXml = "<View><RowLimit>10</RowLimit></View>";
                ListItemCollection pageOfContacts = contactsList.GetItems(query);
                ctx.Load(pageOfContacts);
                ctx.ExecuteQuery();

                itemPosition = pageOfContacts.ListItemCollectionPosition;
                currentPage++;
                Console.WriteLine("Page #: {0}", currentPage);
                foreach (ListItem item in pageOfContacts)
                {
                    Console.WriteLine("Contact: {0}", item["Title"]);
                }
                Console.WriteLine();
            } while (itemPosition != null);
        }

        // Listing 7-23
        static void CreateNewDocumentLibrary()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            ListCreationInformation lci = new ListCreationInformation();
            lci.Title = "Custom Documents";
            lci.Description = "Custom Documents Created by Client Side Object Model";
            lci.TemplateType = (Int32)ListTemplateType.DocumentLibrary;
            lci.QuickLaunchOption = QuickLaunchOptions.On;

            List newList = ctx.Web.Lists.Add(lci);
            ctx.ExecuteQuery();
        }

        // Listing 7-24
        static void UploadFileInDocumentLibrary()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List targetList = ctx.Web.Lists.GetByTitle("Custom Documents");
            ctx.ExecuteQuery();

            FileCreationInformation fci = new FileCreationInformation();
            fci.Content = System.IO.File.ReadAllBytes(@"..\..\SampleFile.txt");
            fci.Url = "SampleFile.txt";
            fci.Overwrite = true;
            File fileToUpload = targetList.RootFolder.Files.Add(fci);
            ctx.Load(fileToUpload);
            ctx.ExecuteQuery();
        }

        // Listing 7-25
        static void DownloadFileFromDocumentLibrary()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List targetList = ctx.Web.Lists.GetByTitle("Custom Documents");
            ctx.Load(targetList, lst => lst.RootFolder);
            ctx.ExecuteQuery();

            String fileToDownload = (targetList.RootFolder.ServerRelativeUrl + "/SampleFile.txt");
            FileInformation fileInfo = File.OpenBinaryDirect(ctx, fileToDownload);
            ctx.ExecuteQuery();

            using (System.IO.StreamReader sr = new System.IO.StreamReader(fileInfo.Stream))
            {
                String content = sr.ReadToEnd();
                Console.WriteLine(content);
            }
        }

        // Listing 7-26
        static void CheckInAndCheckOut()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List targetList = ctx.Web.Lists.GetByTitle("Custom Documents");
            ctx.Load(targetList, lst => lst.RootFolder);
            ctx.ExecuteQuery();

            String fileToRetrieve = (targetList.RootFolder.ServerRelativeUrl + "/SampleFile.txt");
            File file = ctx.Web.GetFileByServerRelativeUrl(fileToRetrieve);
            ctx.Load(file);
            ctx.ExecuteQuery();

            if (file.CheckOutType == CheckOutType.None)
            {
                file.CheckOut();
            }
            else
            {
                file.CheckIn("Finished check-out!", CheckinType.MajorCheckIn);
            }

            ctx.ExecuteQuery();
        }

        // Listing 7-27
        static void MoveOrCopyFile()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/");

            List targetList = ctx.Web.Lists.GetByTitle("Custom Documents");
            ctx.Load(targetList, lst => lst.RootFolder);
            ctx.ExecuteQuery();

            String fileToRetrieve = (targetList.RootFolder.ServerRelativeUrl + "/SampleFile.txt");
            File file = ctx.Web.GetFileByServerRelativeUrl(fileToRetrieve);
            ctx.Load(file);
            ctx.ExecuteQuery();

            file.CopyTo("Shared Documents/SampleFileCopy.txt", true);
            file.MoveTo("Shared Documents/SampleFileMoved.txt", MoveOperations.Overwrite);

            ctx.ExecuteQuery();
        }
    }
}
