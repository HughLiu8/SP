﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DevLeap.SP2013.JSOM.Layouts.DevLeap.SP2013.JSOM
{
    public partial class ShowECMAScriptInAction : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
