﻿using DevLeap.SP2013.REST.DevLeapBookPortalServiceReference;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.SP2013.REST
{
    class Program
    {
        static void Main(string[] args)
        {
            RESTBasics();
            LinqOnREST();
            PagingREST();
            UpdateItemViaREST();
            AddItemViaREST();
            DeleteItemViaREST();
        }

        // Listing 7-28
        private static void RESTBasics()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            foreach (var item in dc.DevLeapContacts)
            {
                Console.WriteLine(item);
            }
        }

        // Listing 7-29
        private static void LinqOnREST()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            var query = from c in dc.DevLeapContacts
                        where c.ContentType == "DevLeapCustomer"
                        select new
                        {
                            c.ContactID,
                            c.Title,
                            c.CompanyName,
                            c.CustomerLevelValue
                        };

            foreach (var item in query)
            {
                Console.WriteLine(item);
            }
        }

        //// Listing 7-30
        //private static void NotWorkingQuery()
        //{
        //    DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
        //            new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
        //    dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

        //    // This query does not work, because join is not supported
        //    var query = from c in dc.DevLeapContacts
        //                where c.ContentType == "DevLeapCustomer"
        //                join i in dc.Invoices on c.Id equals i.InvoiceCustomerLookupId
        //                select new { c.ContactID, c.Title, c.CompanyName, i.Name };
        //}

        // Listing 7-31
        private static void PagingREST()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            // Get the second page, with a page size of 10
            var query = (from c in dc.ContactsCSOM
                         select c).Skip(10).Take(10);
        }

        // Listing 7-32
        private static void UpdateItemViaREST()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            DevLeapContactsItem item = (from c in dc.DevLeapContacts
                                        where c.Id == 1
                                        select c).First();
            item.CompanyName += " - Changed!"; dc.UpdateObject(item);

            dc.SaveChanges();
        }

        // Listing 7-33
        private static void AddItemViaREST()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            DevLeapContactsItem item = new DevLeapContactsItem
            {
                Title = "Sample Customer",
                ContactID = "CC001",
                ContentType = "DevLeapCustomer",
                CompanyName = "Sample Company",
                CountryValue = "Germany",
                CustomerLevelValue = "Level A"
            };
            dc.AddToDevLeapContacts(item);

            dc.SaveChanges();
        }

        // Listing 7-34
        private static void DeleteItemViaREST()
        {
            DevLeapBookPortalDataContext dc = new DevLeapBookPortalDataContext(
                    new Uri("http://devbook.sp2013.local/_vti_bin/ListData.svc"));
            dc.Credentials = System.Net.CredentialCache.DefaultCredentials;

            DevLeapContactsItem item = (from c in dc.DevLeapContacts
                                        where c.ContactID == "CC001"
                                        select c).First();
            dc.DeleteObject(item);

            dc.SaveChanges();
        }
    }
}
