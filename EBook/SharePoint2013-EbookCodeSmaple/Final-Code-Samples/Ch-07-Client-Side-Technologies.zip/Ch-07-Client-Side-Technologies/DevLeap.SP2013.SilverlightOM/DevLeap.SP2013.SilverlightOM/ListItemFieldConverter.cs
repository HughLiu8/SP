﻿using System;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Ink;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Data;
using Microsoft.SharePoint.Client;

namespace DevLeap.SP2013.SilverlightOM
{
    public class ListItemFieldConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // In case the source item is NULL, just stop
            if (value == null)
                return value;

            // In case the fieldName is empty or NULL, just stop
            String fieldName = parameter as String;
            if (String.IsNullOrEmpty(fieldName))
                return null;

            // Cast the source item to ListItem
            ListItem item = value as ListItem;
            if (item != null)
            {
                // Return the field
                return (item[fieldName]);
            }
            else
                return (null);
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            // We do not support two-way conversion
            throw new NotImplementedException();
        }
    }
}
