﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace DevLeap.SP2013.SilverlightOM
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
            loadDevLeapContacts();
        }

        private ListItemCollection allContacts;

        private void loadDevLeapContacts()
        {
            // Open the current ClientContext
            ClientContext ctx = ClientContext.Current;

            // Prepare a reference to the list of "DevLeap Contacts"
            List list = ctx.Web.Lists.GetByTitle("DevLeap Contacts");

            // Prepare a query for all items in the list
            CamlQuery query = CamlQuery.CreateAllItemsQuery();
            allContacts = list.GetItems(query);
            ctx.Load(allContacts);

            // Execute the prepared command against the target ClientContext
            ctx.ExecuteQueryAsync(onQuerySucceeded, onQueryFailed);
        }

        private void onQuerySucceeded(object sender,
            ClientRequestSucceededEventArgs args)
        {
            this.Dispatcher.BeginInvoke(new updateUI(refreshGrid));
        }

        private void onQueryFailed(object sender,
            ClientRequestFailedEventArgs args)
        {
            this.Dispatcher.BeginInvoke(new showExceptionUI(
                showException), args.Exception);
        }

        private delegate void updateUI();

        private void refreshGrid()
        {
            this.AllContactsList.ItemsSource = allContacts;
        }

        private delegate void showExceptionUI(Exception ex);

        private void showException(Exception ex)
        {
            MessageBox.Show(String.Format("Exception occurred: {0}", ex.Message));
        }
    }
}
