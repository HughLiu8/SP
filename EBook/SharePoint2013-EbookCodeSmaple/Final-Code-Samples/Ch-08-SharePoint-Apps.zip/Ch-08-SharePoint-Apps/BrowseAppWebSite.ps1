﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue 

$site = Get-SPSite "http://devbook.sp2013.local/sites/AppsDevelopmentSite/"
Write-Host "Here are the sub-webs of the current site collection root web"
foreach ($web in $site.AllWebs) {
    Write-Host "ID: " $web.ID " - Title: " $web.Title
    if ($web.IsAppWeb -eq $true) {
        Write-Host "App Web Site Author: "$web.Author
        Write-Host "App Web Site Is App Web?" $web.IsAppWeb
        Write-Host "App Web Site Is Root Web?" $web.IsRootWeb
        Write-Host "App Web Site Is Provisioned?" $web.Provisioned
        Write-Host "App Web Site URL?" $web.Site.Url
        Write-Host "App Web Site parent Web Application:" $web.Site.WebApplication
    }
}
