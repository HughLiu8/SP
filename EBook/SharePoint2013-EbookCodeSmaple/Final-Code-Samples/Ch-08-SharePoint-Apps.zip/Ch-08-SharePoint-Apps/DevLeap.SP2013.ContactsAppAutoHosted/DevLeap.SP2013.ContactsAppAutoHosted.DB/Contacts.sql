﻿CREATE TABLE [dbo].[Contacts]
(
	[Id] INT NOT NULL PRIMARY KEY IDENTITY, 
    [ContactDescription] NVARCHAR(200) NULL, 
    [ContactPhone] NVARCHAR(50) NULL, 
    [ContactEmail] NVARCHAR(100) NULL
)
