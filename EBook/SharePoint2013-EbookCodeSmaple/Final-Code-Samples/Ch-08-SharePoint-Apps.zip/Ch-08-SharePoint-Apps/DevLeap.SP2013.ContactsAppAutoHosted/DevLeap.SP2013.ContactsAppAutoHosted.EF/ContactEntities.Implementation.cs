﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DevLeap.SP2013.ContactsAppAutoHosted.EF
{
    public partial class ContactEntities
    {
        public ContactEntities(String connectionString) :
            base(connectionString)
        {
            
        }
    }
}
