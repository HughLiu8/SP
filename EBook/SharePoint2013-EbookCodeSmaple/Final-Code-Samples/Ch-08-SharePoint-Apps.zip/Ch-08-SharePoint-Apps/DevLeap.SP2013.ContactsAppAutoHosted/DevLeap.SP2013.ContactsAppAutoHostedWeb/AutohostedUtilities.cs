﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace DevLeap.SP2013.ContactsAppAutoHostedWeb
{
    public static class AutohostedUtilities
    {
        public static SqlConnection GetSqlAzureDatabaseConnection(HttpRequest request)
        {
            SqlConnection connection;
            Boolean isReadOnly;

            var contextToken = TokenHelper.GetContextTokenFromRequest(request);
            var hostWeb = request["SPHostUrl"];

            using (var clientContext = TokenHelper.GetClientContextWithContextToken(hostWeb, contextToken, request.Url.Authority))
            {
                AppInstance.TryGetAppDatabaseConnectionDirect(clientContext, out connection, out isReadOnly);

                // This code block closes the connection for Entity Framework
                if (connection.State != System.Data.ConnectionState.Closed)
                {
                    connection.Close();
                }
            }

            return (connection);
        }
    }
}