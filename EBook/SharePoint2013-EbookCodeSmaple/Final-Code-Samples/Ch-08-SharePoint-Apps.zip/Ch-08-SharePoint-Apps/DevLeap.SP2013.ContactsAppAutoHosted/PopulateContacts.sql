﻿INSERT INTO Contacts
           (ContactDescription, 
		   ContactPhone,
		   ContactEmail)
     VALUES
			('Paolo Pialorsi',
			'+39-030-123456',
			'paolo@devleap.com')
GO

INSERT INTO Contacts
           (ContactDescription, 
		   ContactPhone,
		   ContactEmail)
     VALUES
			('Marco Russo',
			'+39-011-654321',
			'marco@devleap.com')
GO

INSERT INTO Contacts
           (ContactDescription, 
		   ContactPhone,
		   ContactEmail)
     VALUES
			('Roberto Brunetti',
			'+39-055-123456',
			'roberto@devleap.com')
GO

INSERT INTO Contacts
           (ContactDescription, 
		   ContactPhone,
		   ContactEmail)
     VALUES
			('Luca Regnicoli',
			'+39-055-651243',
			'luka@devleap.com')
GO
