﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Http;

namespace DevLeap.SP2013.MVC4AppAutoHosted
{
    public static class WebApiConfig
    {
        public static void Register(HttpConfiguration config)
        {
            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "api/{controller}/{id}",
                defaults: new { id = RouteParameter.Optional }
            );
        }
    }
}
