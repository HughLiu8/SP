﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using Windows.Data.Json;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=234238

namespace DevLeap.SP2013.RESTAPI.Win8
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        /// <summary>
        /// Invoked when this page is about to be displayed in a Frame.
        /// </summary>
        /// <param name="e">Event data that describes how this page was reached.  The Parameter
        /// property is typically used to configure the page.</param>
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private async void EnsureUser_Click(object sender, RoutedEventArgs e)
        {
            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;
            HttpClient client = new HttpClient(handler);
            client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
            HttpResponseMessage response = await client.PostAsync("http://devbook.sp2013.local/_api/ContextInfo", null);
            String jsonString = await response.Content.ReadAsStringAsync();
            JsonObject o = JsonObject.Parse(jsonString);

            var info = o.FirstOrDefault().Value.GetObject().FirstOrDefault().Value;
            String digest = String.Empty;
            if (info != null)
            {
                digest = info.GetObject()["FormDigestValue"].GetString();
            }

            client.DefaultRequestHeaders.Add("X-RequestDigest", digest);
            response = await client.PostAsync("http://devbook.sp2013.local/_api/web/EnsureUser('Marco.Russo')", null);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Error while invoking EnuserUser method!");
            }
        }

        private async void DownloadLists_Click(object sender, RoutedEventArgs e)
        {
            List<String> listsTitles = new List<string>();

            HttpClientHandler handler = new HttpClientHandler();
            handler.UseDefaultCredentials = true;
            HttpClient client = new HttpClient(handler);
            client.DefaultRequestHeaders.Add("Accept", "application/json;odata=verbose");
            HttpResponseMessage response = await client.GetAsync("http://devbook.sp2013.local/_api/web/lists");
            String jsonString = await response.Content.ReadAsStringAsync();
            JsonObject o = JsonObject.Parse(jsonString);

            foreach (var i in o.FirstOrDefault().Value.GetObject().FirstOrDefault().Value.GetArray())
            {
                JsonObject item = i.GetObject();
                if (!item["Hidden"].GetBoolean())
                    listsTitles.Add(item["Title"].GetString());
            }

            this.ListOfLists.ItemsSource = listsTitles;
        }
    }
}
