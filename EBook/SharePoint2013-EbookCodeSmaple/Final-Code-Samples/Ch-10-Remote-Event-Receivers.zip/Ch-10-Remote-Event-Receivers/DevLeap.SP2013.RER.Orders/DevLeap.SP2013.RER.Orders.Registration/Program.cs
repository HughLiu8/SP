﻿using Microsoft.SharePoint;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DevLeap.SP2013.RER.Orders.Registration
{
    class Program
    {
        static void Main(string[] args)
        {
            using (SPSite site = new SPSite("http://apps-df7c08006f4871.sp2013apps.local/sites/RER/DevLeapSP2013REROrders"))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPList targetList = web.Lists.TryGetList("Orders");

                    // Browse all the already define RER
                    foreach (SPEventReceiverDefinition rer in targetList.EventReceivers)
                    {
                        Console.WriteLine("RER Name: {0}\nType: {1}\nSequence Number: {2}" + 
                            "\nUrl: {3}\nSynchronization: {4}",
                            rer.Name,
                            rer.Type,
                            rer.SequenceNumber,
                            rer.Url,
                            rer.Synchronization
                            );
                        Console.WriteLine("*********************************");
                    }

                    // Add a new RER definition
                    targetList.EventReceivers.Add(
                        SPEventReceiverType.ItemAdding,
                        "http://localhost:2066/OrdersRemoteEventReceiver.svc");
                }
            }

            using (SPSite site = new SPSite("http://devbook.sp2013.local/sites/RER/"))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPList targetList = web.Lists.TryGetList("Documents");

                    // Browse all the already define RER
                    foreach (SPEventReceiverDefinition rer in targetList.EventReceivers)
                    {
                        Console.WriteLine("RER Name: {0}\nType: {1}\nSequence Number: {2}" +
                            "\nUrl: {3}\nSynchronization: {4}",
                            rer.Name,
                            rer.Type,
                            rer.SequenceNumber,
                            rer.Url,
                            rer.Synchronization
                            );
                        Console.WriteLine("*********************************");                   
                    }

                    // Add a new RER definition
                    targetList.EventReceivers.Add(
                        SPEventReceiverType.ItemAdding,
                        "http://localhost:2066/OrdersRemoteEventReceiver.svc");
                }
            }

            using (SPSite site = new SPSite("http://devbook.sp2013.local/sites/RER/"))
            {
                using (SPWeb web = site.OpenWeb())
                {
                    SPList targetList = web.Lists.TryGetList("Documents");

                    // Add a new RER definition
                    targetList.EventReceivers.Add(
                        SPEventReceiverType.ItemAdding,
                        "http://localhost:2066/OrdersRemoteEventReceiver.svc");
                }
            }
        }
    }
}
