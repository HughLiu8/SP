﻿using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.EventReceivers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DevLeap.SP2013.RER.OrdersWeb
{
    public class AppEventReceiver : IRemoteEventService
    {
        public SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties)
        {
            SPRemoteEventResult result = new SPRemoteEventResult();

            // Simply write to the "App Journal" the event
            if (properties.EventType == SPRemoteEventType.AppInstalled ||
                properties.EventType == SPRemoteEventType.AppUpgraded ||
                properties.EventType == SPRemoteEventType.AppUninstalling)
            {
                // Do something with your app-related event
            }

            // Configure a RER for a document library
            if (properties.EventType == SPRemoteEventType.AppInstalled)
            {
                //using (ClientContext clientContext = TokenHelper.CreateAppEventClientContext(
                //    properties, false))
                using (ClientContext clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(
                    properties.AppEventProperties.HostWebFullUrl,
                    System.Security.Principal.WindowsIdentity.GetCurrent()))
                {
                    if (clientContext != null)
                    {
                        List documentsLibrary = clientContext.Web.Lists.GetByTitle("Documents");
                        EventReceiverDefinitionCreationInformation receiverDefinition = new EventReceiverDefinitionCreationInformation();
                        receiverDefinition.EventType = EventReceiverType.ItemAdding;
                        receiverDefinition.ReceiverName = "DocumentItemAddingReceiver";
                        receiverDefinition.ReceiverUrl = String.Format("{0}://{1}/DocumentLibraryReceiver.svc",
                            OperationContext.Current.Channel.LocalAddress.Uri.Scheme,
                            OperationContext.Current.Channel.LocalAddress.Uri.Authority);
                        receiverDefinition.SequenceNumber = 10000;

                        documentsLibrary.EventReceivers.Add(receiverDefinition);
                        clientContext.ExecuteQuery();
                    }
                }
            }
            else if (properties.EventType == SPRemoteEventType.AppUninstalling)
            {
                //using (ClientContext clientContext = TokenHelper.CreateAppEventClientContext(
                //    properties, false))
                using (ClientContext clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(
                    properties.AppEventProperties.HostWebFullUrl,
                    System.Security.Principal.WindowsIdentity.GetCurrent()))
                {
                    if (clientContext != null)
                    {
                        List documentsLibrary = clientContext.Web.Lists.GetByTitle("Documents");
                        clientContext.Load(documentsLibrary.EventReceivers);
                        clientContext.ExecuteQuery();

                        List<EventReceiverDefinition> toDelete = new List<EventReceiverDefinition>();

                        foreach (EventReceiverDefinition rer in documentsLibrary.EventReceivers)
                        {
                            if (rer.ReceiverName == "DocumentItemAddingReceiver")
                            {
                                toDelete.Add(rer);
                            }
                        }

                        if (toDelete.Count > 0)
                        {
                            foreach (EventReceiverDefinition rer in toDelete)
                            {
                                rer.DeleteObject();
                            }
                            clientContext.ExecuteQuery();
                        }
                    }
                }
            }

            return (result);
        }

        public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        {
            // This method is not used by app events. 
        }
    }
}
