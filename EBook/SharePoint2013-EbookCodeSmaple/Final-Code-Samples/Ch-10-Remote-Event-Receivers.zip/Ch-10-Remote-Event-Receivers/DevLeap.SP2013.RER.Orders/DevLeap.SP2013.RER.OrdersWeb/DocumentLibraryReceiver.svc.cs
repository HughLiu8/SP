﻿using Microsoft.SharePoint.Client.EventReceivers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;

namespace DevLeap.SP2013.RER.OrdersWeb
{
    public class DocumentLibraryReceiver : IRemoteEventService
    {
        public SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties)
        {
            SPRemoteEventResult result = new SPRemoteEventResult();

            // If the event is ItemAdding, handle it
            if (properties.EventType == SPRemoteEventType.ItemAdding)
            {
                String documentFileUrl = properties.ItemEventProperties.AfterUrl;
                if (documentFileUrl.Contains("virus"))
                {
                    result.Status = SPRemoteEventServiceStatus.CancelWithError;
                    result.ErrorMessage = "Invalid file name!";
                }
            }
            return (result);
        }

        public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        {
            // This method is not used by app events. 
        }
    }
}
