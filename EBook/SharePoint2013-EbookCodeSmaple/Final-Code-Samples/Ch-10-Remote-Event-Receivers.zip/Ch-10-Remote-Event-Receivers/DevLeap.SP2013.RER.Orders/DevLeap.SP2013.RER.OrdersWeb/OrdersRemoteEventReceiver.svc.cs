﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.EventReceivers;

namespace DevLeap.SP2013.RER.OrdersWeb
{
    public class OrdersRemoteEventReceiver : IRemoteEventService
    {
        public SPRemoteEventResult ProcessEvent(SPRemoteEventProperties properties)
        {
            SPRemoteEventResult result = new SPRemoteEventResult();

            if (properties.EventType == SPRemoteEventType.ItemAdding)
            {
                using (ClientContext clientContext = TokenHelper.CreateRemoteEventReceiverClientContext(properties))
                {
                    if (clientContext != null)
                    {
                        if ((String)properties.ItemEventProperties.AfterProperties["DevLeapOrderStatus"] == "Completed")
                        {
                            result.Status = SPRemoteEventServiceStatus.CancelWithError;
                            result.ErrorMessage = "Order cannot be inserted as 'Completed'";
                        }
                        else
                        {
                            String newTitle = String.Format("{0} - Added on {1}",
                                (String)properties.ItemEventProperties.AfterProperties["Title"],
                                DateTime.Now);
                            result.ChangedItemProperties["Title"] = newTitle;
                        }
                    }
                }
            }
            //else if (properties.EventType == SPRemoteEventType.ItemUpdating)
            //{
            //    using (ClientContext clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(new Uri(properties.ItemEventProperties.WebUrl), System.Security.Principal.WindowsIdentity.GetCurrent())) // .CreateRemoteEventReceiverClientContext(properties))
            //    {
            //        if (clientContext != null)
            //        {
            //            List ordersList = clientContext.Web.Lists.GetByTitle("Orders");
            //            ListItem orderItem = ordersList.GetItemById(properties.ItemEventProperties.ListItemId);

            //            String newTitle = String.Format("{0} - ItemUpdating", (String)properties.ItemEventProperties.AfterProperties["Title"]);
            //            orderItem["Title"] = newTitle;
            //            orderItem.Update();
            //            clientContext.ExecuteQuery();
            //        }
            //    }
            //}

            return result;
        }

        public void ProcessOneWayEvent(SPRemoteEventProperties properties)
        {
            if (properties.EventType == SPRemoteEventType.ItemAdded)
            {
                using (ClientContext clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(new Uri(properties.ItemEventProperties.WebUrl), System.Security.Principal.WindowsIdentity.GetCurrent()))
                {
                    if (clientContext != null)
                    {
                        List ordersList = clientContext.Web.Lists.GetByTitle("Orders");
                        ListItem orderItem = ordersList.GetItemById(properties.ItemEventProperties.ListItemId);

                        String newTitle = String.Format("{0} - ItemAdded Event Raised", (String)properties.ItemEventProperties.AfterProperties["Title"]);
                        orderItem["Title"] = newTitle;
                        orderItem.Update();
                        clientContext.ExecuteQuery();
                    }
                }
            }
        }
    }
}
