﻿using Microsoft.SharePoint.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DevLeap.SP2013.RER.OrdersWeb.Pages
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            appHost.HRef = Request.QueryString["SPAppWebUrl"];
        }

        protected void InsertOrder_Click(object sender, EventArgs e)
        {
            Uri hostWebUri = new Uri(Request.QueryString["SPAppWebUrl"]);

            using (var clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(hostWebUri, Request.LogonUserIdentity))
            {
                List ordersList = clientContext.Web.Lists.GetByTitle("Orders");

                Microsoft.SharePoint.Client.ListItem order =
                    ordersList.AddItem(new ListItemCreationInformation());
                order["Title"] = OrderTitle.Text;
                order["DevLeapOrderID"] = OrderID.Text;
                order["DevLeapOrderStatus"] = OrderStatus.SelectedValue;
                order["DevLeapCustomerID"] = CustomerID.Text;
                order.Update();

                clientContext.ExecuteQuery();
            }
        }

        protected void RefreshOrders_Click(object sender, EventArgs e)
        {
            Uri hostWebUri = new Uri(Request.QueryString["SPAppWebUrl"]);

            using (var clientContext = TokenHelper.GetS2SClientContextWithWindowsIdentity(hostWebUri, Request.LogonUserIdentity))
            {
                List ordersList = clientContext.Web.Lists.GetByTitle("Orders");

                // Prepare the query for Orders
                CamlQuery query = new CamlQuery();
                query.ViewXml = "<View/>";
                Microsoft.SharePoint.Client.ListItemCollection allOrders =
                    ordersList.GetItems(query);
                clientContext.Load(allOrders);

                // Execute the prepared command against the target ClientContext
                clientContext.ExecuteQuery();

                var dataSource = from o in allOrders.ToList()
                                 select new
                                 {
                                     Title = (String)o["Title"],
                                     OrderID = (String)o["DevLeapOrderID"],
                                     Status = (String)o["DevLeapOrderStatus"],
                                     CustomerID = (String)o["DevLeapCustomerID"],
                                 };

                gridOrders.DataSource = dataSource;
                gridOrders.DataBind();
            }
        }
    }
}