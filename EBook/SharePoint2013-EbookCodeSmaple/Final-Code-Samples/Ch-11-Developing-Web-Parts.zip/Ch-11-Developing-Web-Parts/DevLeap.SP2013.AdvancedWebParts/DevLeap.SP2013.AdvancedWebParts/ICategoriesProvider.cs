﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.SP2013.AdvancedWebParts
{
    public interface ICategoriesProvider
    {
        String CategoryId { get; }
    }
}
