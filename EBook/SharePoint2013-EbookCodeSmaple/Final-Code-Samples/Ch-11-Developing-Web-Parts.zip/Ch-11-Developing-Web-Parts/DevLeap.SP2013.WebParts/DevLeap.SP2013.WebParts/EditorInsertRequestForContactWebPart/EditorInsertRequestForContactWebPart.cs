﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DevLeap.SP2013.WebParts.EditorInsertRequestForContactWebPart
{
    [ToolboxItemAttribute(false)]
    public class EditorInsertRequestForContactWebPart : WebPart
    {
        [WebBrowsable(false)]
        [Personalizable(PersonalizationScope.Shared)]
        public Guid TargetListID { get; set; }

        protected TextBox RequesterFullName;
        protected TextBox RequesterEMail;
        protected TextBox Reason;
        protected Button SubmitRequestForContact;
        protected Label ErrorMessage;

        protected override void CreateChildControls()
        {
            if (this.WebPartManager.DisplayMode == WebPartManager.BrowseDisplayMode)
            {
                // Page Display mode
                this.RequesterFullName = new TextBox();
                this.RequesterFullName.Columns = 100;
                this.RequesterFullName.MaxLength = 255;
                this.Controls.Add(new LiteralControl("<div>Requester Full Name: "));
                this.Controls.Add(this.RequesterFullName);
                this.Controls.Add(new LiteralControl("</div>"));

                this.RequesterEMail = new TextBox();
                this.RequesterEMail.Columns = 100;
                this.RequesterEMail.MaxLength = 100;
                this.Controls.Add(new LiteralControl("<div>Requester EMail: "));
                this.Controls.Add(this.RequesterEMail);
                this.Controls.Add(new LiteralControl("</div>"));

                this.Reason = new TextBox();
                this.Reason.Columns = 100;
                this.Reason.MaxLength = 255;
                this.Controls.Add(new LiteralControl("<div>Reason: "));
                this.Controls.Add(this.Reason);
                this.Controls.Add(new LiteralControl("</div>"));

                this.SubmitRequestForContact = new Button();
                this.SubmitRequestForContact.Text = "Submit Request for Contact";
                this.Controls.Add(new LiteralControl("<div>"));
                this.Controls.Add(this.SubmitRequestForContact);
                this.SubmitRequestForContact.Click += new EventHandler(SubmitRequestForContact_Click);
                this.Controls.Add(new LiteralControl("</div>"));

                this.ErrorMessage = new Label();
                this.ErrorMessage.ForeColor = System.Drawing.Color.Red;
                this.Controls.Add(new LiteralControl("<div>"));
                this.Controls.Add(this.ErrorMessage);
                this.Controls.Add(new LiteralControl("</div>"));
            }
            else if (this.WebPartManager.DisplayMode == WebPartManager.DesignDisplayMode)
            {
                // Page Design mode
                this.Controls.Add(new LiteralControl("<div>Please move to Display mode to use this Web Part.</div>"));
            }
            else if (this.WebPartManager.DisplayMode == WebPartManager.EditDisplayMode)
            {
                // Page Edit mode
                this.Controls.Add(new LiteralControl("<div>Please move to Display mode to use this Web Part or configure its properties, since you are in Edit mode.</div>"));
            }
        }

        void SubmitRequestForContact_Click(object sender, EventArgs e)
        {
            SPWeb web = SPControl.GetContextWeb(HttpContext.Current);

            try
            {
                SPList targetList = web.Lists[this.TargetListID];

                SPListItem newItem = targetList.Items.Add();
                newItem["Reason"] = this.Reason.Text;
                newItem["Requester full name"] = this.RequesterFullName.Text;
                newItem["Requester email"] = this.RequesterEMail.Text;
                newItem.Update();
            }
            catch (IndexOutOfRangeException)
            {
                this.ErrorMessage.Text = "Cannot find list \"Requests for Contacts\"";
            }
        }

        public override EditorPartCollection CreateEditorParts()
        {
            RequestForContactEditorPart editorPart = new RequestForContactEditorPart();
            editorPart.ID = this.ID + "_RequestForContactEditorPart";

            EditorPartCollection editorParts =
              new EditorPartCollection(base.CreateEditorParts(), new EditorPart[] { editorPart });
            return editorParts;
        }

        public override object WebBrowsableObject
        {
            get
            {
                return (this);
            }
        }
    }

    public class RequestForContactEditorPart : EditorPart
    {
        protected DropDownList targetLists;

        protected override void CreateChildControls()
        {
            this.targetLists = new DropDownList();

            SPWeb web = SPControl.GetContextWeb(HttpContext.Current);

            foreach (SPList list in web.Lists)
            {
                this.targetLists.Items.Add(new ListItem(list.Title, list.ID.ToString()));
            }

            this.Title = "Request for Contact EditorPart";

            this.Controls.Add(new LiteralControl("Select the target List:<br>"));
            this.Controls.Add(this.targetLists);
            this.Controls.Add(new LiteralControl("<br>&nbsp;<br>"));
        }

        public override bool ApplyChanges()
        {
            EnsureChildControls();

            EditorInsertRequestForContactWebPart wp = this.WebPartToEdit as EditorInsertRequestForContactWebPart;
            if (wp != null)
            {
                wp.TargetListID = new Guid(this.targetLists.SelectedValue);
            }

            return (true);
        }

        public override void SyncChanges()
        {
            EnsureChildControls();

            EditorInsertRequestForContactWebPart wp = this.WebPartToEdit as EditorInsertRequestForContactWebPart;
            if (wp != null)
            {
                ListItem selectedItem = this.targetLists.Items.FindByValue(wp.TargetListID.ToString());
                if (selectedItem != null)
                {
                    this.targetLists.ClearSelection();
                    selectedItem.Selected = true;
                }
            }
        }
    }
}
