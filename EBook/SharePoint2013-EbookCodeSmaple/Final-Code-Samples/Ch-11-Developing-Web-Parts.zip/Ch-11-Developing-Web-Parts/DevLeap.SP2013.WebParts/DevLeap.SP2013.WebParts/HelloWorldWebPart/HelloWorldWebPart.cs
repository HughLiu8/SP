﻿using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DevLeap.SP2013.WebParts.HelloWorldWebPart
{
    [ToolboxItemAttribute(false)]
    public class HelloWorldWebPart : WebPart
    {
        protected override void CreateChildControls()
        {
            SPWeb currentWeb = SPControl.GetContextWeb(HttpContext.Current);
            String currentUserName = currentWeb.CurrentUser.LoginName;
            this.Controls.Add(new LiteralControl(String.Format(
                "<h1>Welcome {0}!</h1>", currentUserName)));
            this.Controls.Add(new LiteralControl(String.Format(
                "<div>Current DateTime: {0}</div>", DateTime.Now)));
        }
    }
}
