﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System;
using System.ComponentModel;
using System.Web;
using System.Web.UI.WebControls.WebParts;

namespace DevLeap.SP2013.WebParts.VisualInsertRequestForContactWebPart
{
    [ToolboxItemAttribute(false)]
    public partial class VisualInsertRequestForContactWebPart : WebPart
    {
        // Uncomment the following SecurityPermission attribute only when doing Performance Profiling on a farm solution
        // using the Instrumentation method, and then remove the SecurityPermission attribute when the code is ready
        // for production. Because the SecurityPermission attribute bypasses the security check for callers of
        // your constructor, it's not recommended for production purposes.
        // [System.Security.Permissions.SecurityPermission(System.Security.Permissions.SecurityAction.Assert, UnmanagedCode = true)]
        public VisualInsertRequestForContactWebPart()
        {
        }

        protected override void OnInit(EventArgs e)
        {
            base.OnInit(e);
            InitializeControl();
        }

        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void SubmitRequestForContact_Click(object sender, EventArgs e)
        {
            SPWeb web = SPControl.GetContextWeb(HttpContext.Current);

            try
            {
                SPList targetList = web.Lists["Requests for Contacts"];

                SPListItem newItem = targetList.Items.Add();
                newItem["Reason"] = this.Reason.Text;
                newItem["Requester full name"] = this.RequesterFullName.Text;
                newItem["Requester email"] = this.RequesterEMail.Text;
                newItem.Update();
            }
            catch (IndexOutOfRangeException)
            {
                this.ErrorMessage.Text = "Cannot find list \"Requests for Contacts\"";
            }
        }
    }
}
