﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.SP2013.UIExtensions
{
    public static class FieldsIds
    {
        public static Guid DevLeapInvoiceNumber_ID = new Guid("{F1D40C65-7A6C-4148-AE99-A6DAE71FD375}");
        public static Guid DevLeapInvoiceDescription_ID = new Guid("{D29E8CB4-35C5-4EB0-AB59-9C834649C3A0}");
        public static Guid DevLeapInvoiceStatus_ID = new Guid("{1F516F60-B435-464F-8B8F-016C04D64CA7}");

        public const String InvoiceStatus_Draft = "Draft";
        public const String InvoiceStatus_Approved = "Approved";
        public const String InvoiceStatus_Sent = "Sent";
        public const String InvoiceStatus_Archived = "Archived";
    }
}
