﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using Microsoft.SharePoint.Utilities;
using System.Web;

// Listing 12-12
namespace DevLeap.SP2013.UIExtensions.Layouts.DevLeap.SP2013.UIExtensions
{
    public partial class DevLeapInvoiceChangeStatus : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            String itemId = this.Request.QueryString["ItemId"];
            String listId = this.Request.QueryString["ListId"];
            String status = this.Request.QueryString["Status"];

            if (!String.IsNullOrEmpty(itemId) &&
                !String.IsNullOrEmpty(listId) &&
                !String.IsNullOrEmpty(status))
            {
                SPWeb web = this.Web;

                try
                {
                    try
                    {
                        SPList list = web.Lists[new Guid(this.Request.QueryString["ListId"])];
                        SPListItem item = list.GetItemById(Int32.Parse(this.Request.QueryString["ItemId"]));

                        web.AllowUnsafeUpdates = true;
                        item[FieldsIds.DevLeapInvoiceStatus_ID] = status;
                        item.Update();

                        SPUtility.Redirect(list.DefaultViewUrl, SPRedirectFlags.Default, HttpContext.Current);
                    }
                    finally
                    {
                        web.AllowUnsafeUpdates = false;
                    }
                }
                catch (ArgumentException)
                {
                    throw new ApplicationException("Invalid List or Item ID!");
                }
            }
        }
    }
}
