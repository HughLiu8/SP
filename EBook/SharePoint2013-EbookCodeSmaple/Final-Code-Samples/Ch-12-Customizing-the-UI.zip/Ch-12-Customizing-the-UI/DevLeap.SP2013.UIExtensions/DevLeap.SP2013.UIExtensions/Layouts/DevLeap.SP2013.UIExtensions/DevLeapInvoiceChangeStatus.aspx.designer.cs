﻿namespace DevLeap.SP2013.UIExtensions.Layouts.DevLeap.SP2013.UIExtensions
{
    public partial class DevLeapInvoiceChangeStatus
    {
    }
}
