﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DevLeap.SP2013.UIExtensions.Layouts.DevLeap.SP2013.UIExtensions
{
    public partial class DevLeapInvoiceChangeStatusDialog : LayoutsPageBase
    {
        public Guid TargetListId
        {
            get { return ((Guid)this.ViewState["TargetListId"]); }
            set { this.ViewState["TargetListId"] = value; }
        }

        public Int32 TargetItemId
        {
            get { return ((Int32)this.ViewState["TargetItemId"]); }
            set { this.ViewState["TargetItemId"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.TargetListId = new Guid(this.Request.QueryString["ListId"]);
                this.TargetItemId = Int32.Parse(this.Request.QueryString["ItemId"]);

                SPWeb web = this.Web;

                try
                {
                    SPList list = web.Lists[this.TargetListId];
                    SPListItem item = list.GetItemById(this.TargetItemId);

                    statusDropDown.ClearSelection();
                    statusDropDown.Items.FindByValue(
                        item[FieldsIds.DevLeapInvoiceStatus_ID].ToString())
                        .Selected = true;
                }
                catch (ArgumentException)
                {
                    throw new ApplicationException("Invalid List or Item ID!");
                }
            }
        }

        protected void okCommand_Clicked(Object sender, EventArgs e)
        {
            SPWeb web = this.Web;

            try
            {
                try
                {
                    SPList list = web.Lists[this.TargetListId];
                    SPListItem item = list.GetItemById(this.TargetItemId);

                    web.AllowUnsafeUpdates = true;
                    item[FieldsIds.DevLeapInvoiceStatus_ID] = statusDropDown.SelectedValue;
                    item.Update();

                    // In case we are in a PopUp dialog, we need to close it
                    if ((SPContext.Current != null) && SPContext.Current.IsPopUI)
                    {
                        this.Context.Response.Write("<script type='text/javascript'>window.frameElement.commonModalDialogClose(1, '" + statusDropDown.SelectedValue + "');</script>");
                        this.Context.Response.Flush();
                        this.Context.Response.End();
                    }
                }
                finally
                {
                    web.AllowUnsafeUpdates = false;
                }
            }
            catch (ArgumentException)
            {
                throw new ApplicationException("Invalid List or Item ID!");
            }
        }
    }
}

