﻿using System;
using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;

namespace DevLeap.SP2013.UIExtensions.Layouts.DevLeap.SP2013.UIExtensions
{
    public partial class InvoicesSettings : LayoutsPageBase
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }
    }
}
