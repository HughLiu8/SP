﻿using Microsoft.SharePoint;
using Microsoft.SharePoint.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;

namespace DevLeap.SP2013.UIExtensions
{
    // Listing 12-9
    public class SwitchToMobileMode : System.Web.UI.WebControls.WebControl
    {
        protected override void CreateChildControls()
        {
            SPWeb web = SPControl.GetContextWeb(HttpContext.Current);

            MenuItemTemplate switchToMobile = new MenuItemTemplate();
            switchToMobile.Text = "Switch to Mobile view";
            switchToMobile.Description = "Switches the current site rendering mode to mobile";
            switchToMobile.ClientOnClickNavigateUrl = String.Format("{0}?Mobile=1", web.Url);

            this.Controls.Add(switchToMobile);
        }
    }
}