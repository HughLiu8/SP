﻿// Default code generation is disabled for model 'C:\SP2013DR\Ch-16-Business-Connectivity-Services\DevLeap.SP2013.ModelSampleCRM\DevLeap.SP2013.ModelSampleCRM\SampleCRM.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.