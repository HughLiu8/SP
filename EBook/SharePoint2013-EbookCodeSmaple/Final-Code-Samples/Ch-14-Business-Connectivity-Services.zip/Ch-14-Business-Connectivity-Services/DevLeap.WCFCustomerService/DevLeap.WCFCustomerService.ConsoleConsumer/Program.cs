﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.WCFCustomerService.ConsoleConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            CustomerServiceReference.CustomerServiceClient svc = new DevLeap.WCFCustomerService.ConsoleConsumer.CustomerServiceReference.CustomerServiceClient();
            var customers = svc.ListAllCustomers();

            foreach (var c in customers)
            {
                c.Print();
            }

            var c01 = svc.GetCustomerById("ID001");
            c01.Print();
        }
    }

    public static class CustomerExtensions
    {
        public static void Print(this CustomerServiceReference.Customer c)
        {
            Console.WriteLine("{0} - {1} - {2} - {3}", c.CustomerID, c.ContactName, c.CompanyName, c.Country);
        }
    }
}
