﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Activities;
using System.ComponentModel.DataAnnotations;

namespace DevLeap.SP2013.CustomActivities
{

    public sealed class CreditCardValidationActivity : CodeActivity<Boolean>
    {
        [RequiredArgument]
        public InArgument<String> CreditCard { get; set; }

        protected override bool Execute(CodeActivityContext context)
        {
            CreditCardAttribute cc = new CreditCardAttribute();
            return (cc.IsValid(this.CreditCard.Get(context)));
        }
    }
}
