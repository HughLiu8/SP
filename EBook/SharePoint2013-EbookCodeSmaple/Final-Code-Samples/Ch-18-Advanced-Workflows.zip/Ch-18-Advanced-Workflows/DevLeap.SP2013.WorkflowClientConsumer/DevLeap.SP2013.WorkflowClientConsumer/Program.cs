﻿using Microsoft.SharePoint.Client;
using Microsoft.SharePoint.Client.WorkflowServices;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.SP2013.WorkflowClientConsumer
{
    class Program
    {
        static void Main(string[] args)
        {
            EnumerateWorkflowSubscriptions();
            TerminateAllWorkflowInstances();

            String xaml = null;
            using (FileStream fs = new FileStream(@"..\..\workflow.xml", FileMode.Open, FileAccess.Read))
            {
                using (StreamReader sr = new StreamReader(fs))
                {
                    xaml = sr.ReadToEnd();
                }
            }
            PublishXamlWorkflowToWorkflowStore(xaml);
        }

        private static void PublishXamlWorkflowToWorkflowStore(String xaml)
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/sites/Workflows/");
            Web web = ctx.Web;
            ctx.Load(web);
            List documents = web.Lists.GetByTitle("Documents");
            ctx.Load(documents);
            ctx.ExecuteQuery();

            WorkflowServicesManager wfManager = new WorkflowServicesManager(ctx, web);
            WorkflowDeploymentService deploymentService = wfManager.GetWorkflowDeploymentService();

            var validationResult = deploymentService.ValidateActivity(xaml);
            ctx.ExecuteQuery();

            WorkflowDefinition definition = new WorkflowDefinition(ctx);
            definition.Xaml = xaml;
            definition.DisplayName = "Sample XAML based Workflow";
            definition.Description = "Workflow saved by code";
            deploymentService.SaveDefinition(definition);
            ctx.ExecuteQuery();
        }

        private static void TerminateAllWorkflowInstances()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/sites/Workflows/");
            Web web = ctx.Web;
            ctx.Load(web);
            List documents = web.Lists.GetByTitle("Documents");
            ctx.Load(documents);
            ctx.ExecuteQuery();

            WorkflowServicesManager wfManager = new WorkflowServicesManager(ctx, web);
            WorkflowInstanceService instanceService = wfManager.GetWorkflowInstanceService();

            ListItemCollection items = documents.GetItems(CamlQuery.CreateAllItemsQuery());
            ctx.Load(items);
            ctx.ExecuteQuery();

            foreach (ListItem item in items)
            {
                WorkflowInstanceCollection instances = instanceService.EnumerateInstancesForListItem(documents.Id, item.Id);
                ctx.Load(instances);
                ctx.ExecuteQuery();

                foreach (var instance in instances)
                {
                    if (instance.Status == WorkflowStatus.Started || instance.Status == WorkflowStatus.Suspended)
                        instanceService.TerminateWorkflow(instance);
                }
                ctx.ExecuteQuery();
            }
        }

        private static void EnumerateWorkflowSubscriptions()
        {
            ClientContext ctx = new ClientContext("http://devbook.sp2013.local/sites/Workflows/");
            Web web = ctx.Web;
            ctx.Load(web);
            List documents = web.Lists.GetByTitle("Documents");
            ctx.Load(documents);
            ctx.ExecuteQuery();

            WorkflowServicesManager wfManager = new WorkflowServicesManager(ctx, web);
            WorkflowSubscriptionService subscriptionService =
                wfManager.GetWorkflowSubscriptionService();
            ctx.Load(subscriptionService);
            WorkflowSubscriptionCollection subscriptions =
                subscriptionService.EnumerateSubscriptionsByList(documents.Id);

            ctx.Load(subscriptions);
            ctx.ExecuteQuery();

            foreach (var s in subscriptions)
            {
                Console.WriteLine("******************************************");
                Console.WriteLine("Id: {0}", s.Id);
                Console.WriteLine("Name: {0}", s.Name);
                Console.WriteLine("DefinitionId: {0}", s.DefinitionId);
                Console.WriteLine("Enabled: {0}", s.Enabled);
                Console.WriteLine("EventSourceId: {0}", s.EventSourceId);
                Console.WriteLine("EventTypes");
                foreach (var e in s.EventTypes)
                {
                    Console.WriteLine("EventType: {0}", e);
                }
                Console.WriteLine("ManualStartBypassesActivationLimit: {0}", s.ManualStartBypassesActivationLimit);
                Console.WriteLine("PropertyDefinitions");
                foreach (var p in s.PropertyDefinitions)
                {
                    Console.WriteLine("Property: {0} - Value: {1}", p.Key, p.Value);
                }
                Console.WriteLine("StatusFieldName: {0}", s.StatusFieldName);
                Console.ReadLine();
            }
        }
    }
}
