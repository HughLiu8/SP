﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue 

#Add-SPSolution -LiteralPath "C:\SP2013DR\Ch-20-Claims-Fed-OAuth\DevLeap.IPSTS\DevLeap.IPSTS.ProvisionProviders\bin\Debug\DevLeap.IPSTS.ProvisionProviders.wsp"
#Install-SPSolution -Identity "DevLeap.IPSTS.ProvisionProviders.wsp" -GACDeployment -Force
#Enable-SPFeature -Identity 24fd07f9-3ddd-4b86-9d0c-c3efe217a70b -Force -Confirm

$AuthNAppHostHeader = "claims.sp2013.local"
$Zone = "Default"

$cp = Get-SPClaimProvider | where-object {$_.TypeName -eq "DevLeap.IPSTS.Providers.DevLeapClaimsProvider"}
$webApp = Get-SPWebApplication "http://$AuthNAppHostHeader"

if ($webApp.IisSettings.ContainsKey($Zone)) 
{
    $settings = $webApp.GetIisSettingsWithFallback($Zone) 
    $providers = $settings.ClaimsProviders 

    if( -not($providers.Contains($cp))) {
        $providers += $cp

        Set-SPWebApplication -Identity $webApp -Zone $Zone -AdditionalClaimProvider $providers
        Write-Host "Registered" $cp.DisplayName "on" $webApp.Url "in zone $Zone"
    }else {
        Write-Host $cp.DisplayName "already registered on" $webApp.Url "in zone $Zone"
    }
} 

# Remove-SPClaimProvider -Identity $cp