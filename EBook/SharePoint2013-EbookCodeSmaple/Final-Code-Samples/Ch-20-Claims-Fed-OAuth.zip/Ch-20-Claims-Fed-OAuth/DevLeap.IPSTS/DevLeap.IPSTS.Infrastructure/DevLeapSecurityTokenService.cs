﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel;
using System.IdentityModel.Configuration;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Profile;
using System.Xml.Serialization;

namespace DevLeap.IPSTS.Infrastructure
{
    public class DevLeapSecurityTokenService : SecurityTokenService
    {
        /// <summary>
        /// Creates an instance of DevLeapSecurityTokenService.
        /// </summary>
        /// <param name="configuration">The SecurityTokenServiceConfiguration.</param>
        public DevLeapSecurityTokenService(SecurityTokenServiceConfiguration configuration)
            : base(configuration)
        {
        }

        /// <summary>
        /// This method returns the configuration for the token issuance request. The configuration
        /// is represented by the Scope class. In our case, we are only capable of issuing a token for a
        /// single RP identity represented by the EncryptingCertificateName.
        /// </summary>
        /// <param name="principal">The caller's principal.</param>
        /// <param name="request">The incoming RST.</param>
        /// <returns>The scope information to be used for the token issuance.</returns>
        protected override Scope GetScope(System.Security.Claims.ClaimsPrincipal principal, System.IdentityModel.Protocols.WSTrust.RequestSecurityToken request)
        {
            // RP validation disabled for the sake of simplicity
            // ValidateAppliesTo(request.AppliesTo);

            Scope scope = new Scope(request.AppliesTo.Uri.OriginalString, SecurityTokenServiceConfiguration.SigningCredentials);
            scope.ReplyToAddress = scope.AppliesToAddress;
            scope.SymmetricKeyEncryptionRequired = false;
            scope.TokenEncryptionRequired = false;

            return (scope);
        }

        /// <summary>
        /// This method returns the claims to be issued in the token.
        /// </summary>
        /// <param name="principal">The caller's principal.</param>
        /// <param name="request">The incoming RST, can be used to obtain addtional information.</param>
        /// <param name="scope">The scope information corresponding to this request.</param> 
        /// <exception cref="ArgumentNullException">If 'principal' parameter is null.</exception>
        /// <returns>The outgoing claimsIdentity to be included in the issued token.</returns>
        protected override System.Security.Claims.ClaimsIdentity GetOutputClaimsIdentity(System.Security.Claims.ClaimsPrincipal principal, System.IdentityModel.Protocols.WSTrust.RequestSecurityToken request, Scope scope)
        {
            if (null == principal)
            {
                throw new ArgumentNullException("principal");
            }


            Claim[] targetClaims = null;
            XmlSerializer xs = new XmlSerializer(typeof(ClaimTypes));
            
            ProfileBase profile = ProfileBase.Create(principal.Identity.Name);

            if (profile != null)
            {
                using (StreamReader sr = new StreamReader(HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["ClaimTypesFilePath"])))
                {
                    ClaimTypes cts = xs.Deserialize(sr) as ClaimTypes;
                    targetClaims =
                        (from c in new List<ClaimTypesClaimType>(cts.ClaimType)
                         select new Claim(c.Type,
                             (String)profile.GetPropertyValue(c.Name),
                             ClaimValueTypes.String)
                        ).ToArray();
                }
            }

            ClaimsIdentity ci = new ClaimsIdentity(targetClaims);
            return (ci);
        }
    }
}
