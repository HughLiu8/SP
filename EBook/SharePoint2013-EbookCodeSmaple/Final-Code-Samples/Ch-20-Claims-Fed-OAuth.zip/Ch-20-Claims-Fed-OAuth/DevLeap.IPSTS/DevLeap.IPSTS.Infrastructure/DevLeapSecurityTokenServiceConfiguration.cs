﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Configuration;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.IPSTS.Infrastructure
{
    public class DevLeapSecurityTokenServiceConfiguration : SecurityTokenServiceConfiguration
    {
        private static Lazy<DevLeapSecurityTokenServiceConfiguration> _configuration =
            new Lazy<DevLeapSecurityTokenServiceConfiguration>(delegate {
                return (new DevLeapSecurityTokenServiceConfiguration());
            }, true);

        public DevLeapSecurityTokenServiceConfiguration() :
            base(ConfigurationManager.AppSettings["IssuerUri"],
            X509Helper.RetrieveSigningCredentials())
        {
            SecurityTokenService = typeof(DevLeapSecurityTokenService);
        }

        public static DevLeapSecurityTokenServiceConfiguration Current
        {
            get { return _configuration.Value; }
        }
    }
}
