﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IdentityModel.Tokens;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.IPSTS.Infrastructure
{
    internal static class X509Helper
    {
        internal static X509Certificate2 GetCertificateByThumbprint(String thumbprint)
        {
            X509Store store = new X509Store(
                StoreName.My,
                StoreLocation.LocalMachine);

            store.Open(OpenFlags.ReadOnly);

            var certificates = store.Certificates.Find(
                X509FindType.FindByThumbprint,
                thumbprint,
                false);

            if (certificates.Count > 0)
            {
                return (certificates[0]);
            }
            else
            {
                return (null);
            }
        }

        internal static X509Certificate2 GetCertificateBySubjectName(String subjectName)
        {
            X509Store store = new X509Store(
                StoreName.My,
                StoreLocation.LocalMachine);

            store.Open(OpenFlags.ReadOnly);

            var certificates = store.Certificates.Find(
                X509FindType.FindBySubjectName,
                subjectName,
                false);

            if (certificates.Count > 0)
            {
                return (certificates[0]);
            }
            else
            {
                return (null);
            }
        }

        internal static X509Certificate2 RetrieveSigningCertificate(String signingCertificateSubjectName)
        {
            var signingCertificate = X509Helper.GetCertificateBySubjectName(
                signingCertificateSubjectName);
            if (signingCertificate == null)
            {
                throw new ConfigurationErrorsException("Invalid configuration for signing certificate SubjectName");
            }
            else
            {
                return(signingCertificate);
            }
        }

        internal static SigningCredentials RetrieveSigningCredentials()
        {
            String signingCertificateThumbprint = ConfigurationManager.AppSettings["SigningCertificateThumbprint"];
            String signingCertificateSubjectName = ConfigurationManager.AppSettings["SigningCertificateName"];
            X509Certificate2 signingCertificate = null;

            if (!String.IsNullOrEmpty(signingCertificateThumbprint))
            {
                signingCertificate = X509Helper.GetCertificateByThumbprint(
                    signingCertificateThumbprint);
            }
            else if (!String.IsNullOrEmpty(signingCertificateSubjectName))
            {
                signingCertificate = X509Helper.GetCertificateBySubjectName(
                    signingCertificateSubjectName);
            }

            if (signingCertificate == null)
            {
                throw new ConfigurationErrorsException("Invalid configuration for signing certificate SubjectName");
            }
            else
            {
                return new X509SigningCredentials(signingCertificate);
            }
        }
    }
}
