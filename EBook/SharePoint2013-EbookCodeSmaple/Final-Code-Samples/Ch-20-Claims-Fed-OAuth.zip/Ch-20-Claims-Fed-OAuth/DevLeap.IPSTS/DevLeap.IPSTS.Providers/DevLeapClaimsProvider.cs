﻿using Microsoft.SharePoint.Administration.Claims;
using Microsoft.SharePoint.WebControls;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DevLeap.IPSTS.Providers
{
    public class DevLeapClaimsProvider: SPClaimProvider
    {
        private static String genderClaimType = "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender";
        private static String favoriteColorClaimType = "http://schemas.devleap.com/SampleIPSTS/claims/favoritecolor";
        private static String fidelityProgramLevelClaimType = "http://schemas.devleap.com/SampleIPSTS/claims/fidelityProgramLevel";

        public DevLeapClaimsProvider(String displayName)
            : base(displayName)
        {
        }


        public static String ProviderDisplayName
        {
            get
            {
                return "DevLeap Claims Provider";
            }
        }


        internal static String ProviderInternalName
        {
            get
            {
                return "DevLeapClaimsProvider";
            }
        }


        public override String Name
        {
            get
            {
                return ProviderInternalName;
            }
        }

        // Available values for the Gender claim
        private String[] genderValues = new String[] { "Male", "Female" };

        // Available values for the FavoriteColor claim
        private String[] favoriteColorValues = new String[] { "White", "Green", "Yellow", "Red", "Blue", "Black" };

        // Available values for the FavoriteColor claim
        private String[] fidelityProgramLevels = new String[] { "Bronze", "Silver", "Gold", "Platinum" };

        protected override void FillClaimsForEntity(Uri context, SPClaim entity, List<SPClaim> claims)
        {
            // Here you can augment the claims for a specific user, after authentication
            // and before the user achieves the requeste Sharepoint pages resources

            if (entity == null)
                throw new ArgumentNullException("entity");

            if (claims == null)
                throw new ArgumentNullException("claims");

            Random rnd = new Random(DateTime.Now.Millisecond);
            Int32 fakeFidelityProgramLevel = rnd.Next(4);

            //Add a fake sample claim
            claims.Add(CreateClaim(
                fidelityProgramLevelClaimType,
                fidelityProgramLevels[fakeFidelityProgramLevel], // This is a random value
                Microsoft.IdentityModel.Claims.ClaimValueTypes.String));
        }

        protected override void FillClaimTypes(List<string> claimTypes)
        {
            // Here you can provide the list of claim types provided
            // by the current claims provider

            if (claimTypes == null)
                throw new ArgumentNullException("claimTypes");

            // Add the custom claim to the list of claimTypes
            claimTypes.Add(fidelityProgramLevelClaimType);
        }

        protected override void FillClaimValueTypes(List<string> claimValueTypes)
        {
            // Here you can provide the list of claim value types provided
            // by the current claims provider

            if (claimValueTypes == null)
                throw new ArgumentNullException("claimValueTypes");

            //Add the custom claim value type to the list of claimValueTypes
            claimValueTypes.Add(Microsoft.IdentityModel.Claims.ClaimValueTypes.String);
        }

        protected override void FillEntityTypes(List<string> entityTypes)
        {
            // Here you can define the type of entity claims provided
            // by the current claims provider

            // Add a role claim type, here to create custom roles based
            // on gender and favoriteColor
            entityTypes.Add(SPClaimEntityTypes.FormsRole);
        }

        protected override void FillHierarchy(Uri context, string[] entityTypes, string hierarchyNodeID, int numberOfLevels, Microsoft.SharePoint.WebControls.SPProviderHierarchyTree hierarchy)
        {
            // Check if the picker is requesting the types we effectively return
            // Because this custom claims provider returns (see FillEntityTypes method, above) roles
            // simply continue in case the request is for role claims
            if (!EntityTypesContain(entityTypes, SPClaimEntityTypes.FormsRole))
                return;

            //Check to see if the hierarchyNodeID is null; it will be when the control 
            //is first loaded but if a user clicks on one of the nodes it will return
            //the key of the node that was clicked.
            switch (hierarchyNodeID)
            {
                case null:

                    // Add support hierarchy of values for gender claim
                    SPProviderHierarchyNode genderRootNode = new SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Gender",
                            "Gender",
                            true);
                    hierarchy.AddChild(genderRootNode);

                    //foreach (String gender in genderValues)
                    //{
                    //    genderRootNode.AddChild(new
                    //        Microsoft.SharePoint.WebControls.SPProviderHierarchyNode(
                    //            DevLeapClaimsProvider.ProviderInternalName,
                    //            gender,
                    //            gender,
                    //            true));
                    //}

                    // Add support hierarchy of values for favoriteColor claim
                    SPProviderHierarchyNode favoriteColorRootNode = new SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Favorite Color",
                            "FavoriteColor",
                            true);
                    hierarchy.AddChild(favoriteColorRootNode);

                    //foreach (String color in favoriteColorValues)
                    //{
                    //    favoriteColorRootNode.AddChild(new
                    //        Microsoft.SharePoint.WebControls.SPProviderHierarchyNode(
                    //            DevLeapClaimsProvider.ProviderInternalName,
                    //            color,
                    //            color,
                    //            true));
                    //}

                    // Add support hierarchy of values for fidelity program level claim
                    SPProviderHierarchyNode fidelityRootNode = new SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Fidelity Program Level",
                            "FidelityProgramLevel",
                            true);
                    hierarchy.AddChild(fidelityRootNode);

                    //// For each of the available fidelity program levels
                    //// define a child node in the hierarchyx
                    //// Remember that the fidelityProgramLevel is a custom
                    //// augmented claim provided by this custom claims provider
                    //foreach (String level in fidelityProgramLevels)
                    //{
                    //    fidelityRootNode.AddChild(new
                    //        Microsoft.SharePoint.WebControls.SPProviderHierarchyNode(
                    //            DevLeapClaimsProvider.ProviderInternalName,
                    //            level,
                    //            level,
                    //            true));
                    //}

                    break;
                default:
                    break;
            }
        }


        protected override void FillResolve(Uri context, string[] entityTypes, SPClaim resolveInput, List<Microsoft.SharePoint.WebControls.PickerEntity> resolved)
        {
            // Check if the picker is requesting the types we effectively return
            // Because this custom claims provider returns (see FillEntityTypes method, above) roles
            // simply continue in case the request is for role claims
            if (!EntityTypesContain(entityTypes, SPClaimEntityTypes.FormsRole))
                return;

            resolveInputValue(resolveInput.Value, resolved);
        }

        protected override void FillResolve(Uri context, string[] entityTypes, string resolveInput, List<Microsoft.SharePoint.WebControls.PickerEntity> resolved)
        {
            // Check if the picker is requesting the types we effectively return
            // Because this custom claims provider returns (see FillEntityTypes method, above) roles
            // simply continue in case the request is for role claims
            if (!EntityTypesContain(entityTypes, SPClaimEntityTypes.FormsRole))
                return;

            resolveInputValue(resolveInput, resolved);
        }

        private void resolveInputValue(String resolveInput, List<Microsoft.SharePoint.WebControls.PickerEntity> resolved)
        {
            // Look for any matching value in the gender claim values
            foreach (String gender in genderValues)
            {
                if (gender.ToLower() == resolveInput.ToLower())
                {
                    // We have a match, create a matching entity.
                    PickerEntity pe = GetPickerEntity(gender, genderClaimType, "Gender");

                    // Add it to the return list of picker entries.
                    resolved.Add(pe);
                }
            }

            // Look for any matching value in the favoriteColor claim values
            foreach (String color in favoriteColorValues)
            {
                if (color.ToLower() == resolveInput.ToLower())
                {
                    // We have a match, create a matching entity.
                    PickerEntity pe = GetPickerEntity(color, favoriteColorClaimType, "Favorite Color");

                    // Add it to the return list of picker entries.
                    resolved.Add(pe);
                }
            }

            // Look for any matching value in the fidelity program levels
            foreach (String level in fidelityProgramLevels)
            {
                if (level.ToLower() == resolveInput.ToLower())
                {
                    // We have a match, create a matching entity.
                    PickerEntity pe = GetPickerEntity(level, fidelityProgramLevelClaimType, "Fidelity Program Level");

                    // Add it to the return list of picker entries.
                    resolved.Add(pe);
                }
            }
        }

        protected override void FillSchema(Microsoft.SharePoint.WebControls.SPProviderSchema schema)
        {
            // Add the schema element we need at a minimum in our picker node.
            schema.AddSchemaElement(new
                SPSchemaElement(PeopleEditorEntityDataKeys.DisplayName, "Display Name", SPSchemaElementType.Both));
        }

        protected override void FillSearch(Uri context, string[] entityTypes, string searchPattern, string hierarchyNodeID, int maxCount, Microsoft.SharePoint.WebControls.SPProviderHierarchyTree searchTree)
        {
            // Check if the picker is requesting the types we effectively return
            // Because this custom claims provider returns (see FillEntityTypes method, above) roles
            // simply continue in case the request is for role claims
            if (!EntityTypesContain(entityTypes, SPClaimEntityTypes.FormsRole))
                return;

            // Nodes where we will stick our matches
            Microsoft.SharePoint.WebControls.SPProviderHierarchyNode matchNode = null;

            #region Fidelity Program Levels

            // Look to see if the value that is typed in matches any of the claims values
            foreach (string level in fidelityProgramLevels)
            {
                if (level.ToLower().StartsWith(searchPattern.ToLower()))
                {
                    // We have a match, create a matching entity
                    PickerEntity pe = GetPickerEntity(level, fidelityProgramLevelClaimType, "Fidelity Program Level");

                    // Add the level node where it should be displayed too.
                    if (!searchTree.HasChild(level))
                    {
                        // Create the node so we can show our match in there too.
                        matchNode = new
                            SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Fidelity Program Level",
                            "FidelityProgramLevel",
                            true);

                        // Add it to the tree
                        searchTree.AddChild(matchNode);
                    }
                    else
                        // Get the node for this team.
                        matchNode = searchTree.Children.Where(theNode =>
                            theNode.HierarchyNodeID == level).First();

                    // Add the match to our node.
                    matchNode.AddEntity(pe);
                }
            }
            #endregion

            #region Gender

            // Look to see if the value that is typed in matches any of the claims values
            foreach (string gender in genderValues)
            {
                if (gender.ToLower().StartsWith(searchPattern.ToLower()))
                {
                    // We have a match, create a matching entity
                    PickerEntity pe = GetPickerEntity(gender, genderClaimType, "Gender");

                    // Add the gender node where it should be displayed too.
                    if (!searchTree.HasChild(gender))
                    {
                        // Create the node so we can show our match in there too.
                        matchNode = new
                            SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Gender",
                            "Gender",
                            true);

                        // Add it to the tree
                        searchTree.AddChild(matchNode);
                    }
                    else
                        // Get the node for this team.
                        matchNode = searchTree.Children.Where(theNode =>
                            theNode.HierarchyNodeID == gender).First();

                    // Add the match to our node.
                    matchNode.AddEntity(pe);
                }
            }
            #endregion

            #region FavoriteColor

            // Look to see if the value that is typed in matches any of the claims values
            foreach (string color in favoriteColorValues)
            {
                if (color.ToLower().StartsWith(searchPattern.ToLower()))
                {
                    // We have a match, create a matching entity
                    PickerEntity pe = GetPickerEntity(color, favoriteColorClaimType, "Favorite Color");

                    // Add the color node where it should be displayed too.
                    if (!searchTree.HasChild(color))
                    {
                        // Create the node so we can show our match in there too.
                        matchNode = new
                            SPProviderHierarchyNode(
                            DevLeapClaimsProvider.ProviderInternalName,
                            "Favorite Color",
                            "FavoriteColor",
                            true);

                        // Add it to the tree
                        searchTree.AddChild(matchNode);
                    }
                    else
                        // Get the node for this team.
                        matchNode = searchTree.Children.Where(theNode =>
                            theNode.HierarchyNodeID == color).First();

                    // Add the match to our node.
                    matchNode.AddEntity(pe);
                }
            }
            #endregion
        }


        private PickerEntity GetPickerEntity(string claimValue, String claimType, String claimName)
        {
            // We have a match, create a matching entity.
            PickerEntity pe = CreatePickerEntity();

            // Set the claim associated with this match
            // In the current example all the claims are of type String
            pe.Claim = CreateClaim(claimType, claimValue, 
                Microsoft.IdentityModel.Claims.ClaimValueTypes.String);
            
            // Set the tooltip that is displayed when you hover over the resolved claim
            pe.Description = DevLeapClaimsProvider.ProviderDisplayName + ":" + claimValue;

            // Set the text we will display.
            pe.DisplayText = claimValue;

            // Store it here too in the hashtable **.
            pe.EntityData[PeopleEditorEntityDataKeys.DisplayName] = claimValue;

            // User entity.
            pe.EntityType = SPClaimEntityTypes.FormsRole;

            // Flag the entry as being resolved.
            pe.IsResolved = true;

            // This is the first part of the description that shows
            // up above the matches, like Role: Forms Authentication when
            // you do an FBA search and find a matching role.
            pe.EntityGroupName = claimName;

            return pe;
        }


        public override bool SupportsEntityInformation
        {
            get
            {
                return true;
            }
        }

        public override bool SupportsHierarchy
        {
            get
            {
                return true;
            }
        }

        public override bool SupportsResolve
        {
            get
            {
                return true;
            }
        }

        public override bool SupportsSearch
        {
            get
            {
                return true;
            }
        }
    }
}
