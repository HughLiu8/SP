using System;
using System.Runtime.InteropServices;
using System.Security.Permissions;
using Microsoft.SharePoint;
using Microsoft.SharePoint.Administration.Claims;
using DevLeap.IPSTS.Providers;

namespace DevLeap.IPSTS.ProvisionProviders.Features.ProvisioningFeature
{
    [Guid("db91c26b-22d0-4eb5-ad9a-9870e2e5ff4b")]
    public class ProvisioningFeatureEventReceiver : SPClaimProviderFeatureReceiver
    {

        private void ExecBaseFeatureActivated(Microsoft.SharePoint.SPFeatureReceiverProperties properties)
        {
            base.FeatureActivated(properties);
        }

        public override string ClaimProviderAssembly
        {
            get
            {
                return typeof(DevLeapClaimsProvider).Assembly.FullName;
            }
        }

        public override string ClaimProviderType
        {
            get
            {
                return typeof(DevLeapClaimsProvider).FullName;
            }
        }

        public override string ClaimProviderDisplayName
        {
            get
            {
                return DevLeapClaimsProvider.ProviderDisplayName;
            }
        }

        public override string ClaimProviderDescription
        {
            get
            {
                return "A sample provider to augment claims and resolve claims provided by sample IP/STS";
            }
        }

        public override void FeatureActivated(SPFeatureReceiverProperties properties)
        {
            ExecBaseFeatureActivated(properties);
            SPClaimProviderManager cpm = SPClaimProviderManager.Local;
            foreach (SPClaimProviderDefinition cp in cpm.ClaimProviders)
            {
                if (cp.ClaimProviderType == typeof(DevLeapClaimsProvider))
                {
                    cp.IsUsedByDefault = true;
                    cpm.Update();
                    break;
                }
            }
        }
    }
}
