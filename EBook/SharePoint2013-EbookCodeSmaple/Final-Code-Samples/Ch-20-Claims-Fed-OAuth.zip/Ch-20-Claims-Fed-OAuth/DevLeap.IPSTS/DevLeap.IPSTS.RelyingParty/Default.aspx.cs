﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DevLeap.IPSTS.RelyingParty
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (this.User != null && this.User.Identity != null)
            {
                ClaimsIdentity ci = this.User.Identity as ClaimsIdentity;
                if (ci != null)
                {
                    var claims = (from c in ci.Claims
                                 select new { c.Type, c.Value }).ToArray();

                    this.gridClaims.DataSource = claims;
                    this.gridClaims.DataBind();
                }
            }
        }
    }
}