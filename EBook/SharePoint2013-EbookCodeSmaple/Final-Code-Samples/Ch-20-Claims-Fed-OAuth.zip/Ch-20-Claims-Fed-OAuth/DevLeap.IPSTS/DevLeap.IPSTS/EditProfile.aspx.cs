﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Profile;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DevLeap.IPSTS
{
    public partial class EditProfile : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!this.IsPostBack)
            {
                this.Name.Text = (String)HttpContext.Current.Profile.GetPropertyValue("Name");
                this.Email.Text = (String)HttpContext.Current.Profile.GetPropertyValue("Email");
                this.Gender.Text = (String)HttpContext.Current.Profile.GetPropertyValue("Gender");
                this.FavoriteColor.Text = (String)HttpContext.Current.Profile.GetPropertyValue("FavoriteColor");
            }
        }

        protected void SaveProfile_Click(object sender, EventArgs e)
        {
            HttpContext.Current.Profile.SetPropertyValue("Name", this.Name.Text);
            HttpContext.Current.Profile.SetPropertyValue("Email", this.Email.Text);
            HttpContext.Current.Profile.SetPropertyValue("Gender", this.Gender.Text);
            HttpContext.Current.Profile.SetPropertyValue("FavoriteColor", this.FavoriteColor.Text);
        }
    }
}