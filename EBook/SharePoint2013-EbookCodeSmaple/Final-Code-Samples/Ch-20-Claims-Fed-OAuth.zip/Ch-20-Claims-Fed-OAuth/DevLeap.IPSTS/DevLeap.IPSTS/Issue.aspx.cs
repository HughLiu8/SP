﻿using DevLeap.IPSTS.Infrastructure;
using System;
using System.Collections.Generic;
using System.IdentityModel.Services;
using System.Linq;
using System.Security.Claims;
using System.Security.Principal;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DevLeap.IPSTS
{
    public partial class Issue : System.Web.UI.Page
    {
        private WSFederationMessage message = null;
        private SignInRequestMessage signInMessage = null;

        private void ensureFederationMessages()
        {
            if (this.message == null)
            {
                try
                {
                    this.message = WSFederationMessage.CreateFromUri(Request.Url);
                    if (this.message.Action == WSFederationConstants.Actions.SignIn)
                    {
                        this.signInMessage = this.message as SignInRequestMessage;
                    }
                }
                catch (WSFederationMessageException)
                {
                    Response.Redirect(FormsAuthentication.DefaultUrl);
                }
            }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            // Check for WS-Federation input message
            ensureFederationMessages();

            if (!IsPostBack)
            {
                if (this.message.Action == WSFederationConstants.Actions.SignIn)
                {
                    // Get the subject from cookie authentication
                    if (this.User != null && this.User.Identity != null && this.User.Identity.IsAuthenticated)
                    {
                        ProcessRequest(this.User.Identity);
                    }
                }
                else if (this.message.Action == WSFederationConstants.Actions.SignOut)
                {
                    SignOutRequestMessage requestMessage = (SignOutRequestMessage)WSFederationMessage.CreateFromUri(Request.Url);
                    FederatedPassiveSecurityTokenServiceOperations.ProcessSignOutRequest(
                        requestMessage,
                        (ClaimsPrincipal)User,
                        requestMessage.Reply,
                        this.Response);
                }
            }
        }

        protected void ProcessRequest(IIdentity identity)
        {
            var principal = new ClaimsPrincipal(new ClaimsIdentity[] { (ClaimsIdentity)identity });

            FederatedPassiveSecurityTokenServiceOperations.ProcessRequest(
                this.Request,
                principal,
                DevLeapSecurityTokenServiceConfiguration.Current.CreateSecurityTokenService(),
                this.Response);
        }

        protected void loginControl_Authenticate(object sender, AuthenticateEventArgs e)
        {
            IIdentity identity = null;
            if (Membership.ValidateUser(loginControl.UserName, loginControl.Password))
            {
                // Authentication succeded
                identity = new GenericIdentity(loginControl.UserName);
            }
            else
            {
                return;
            }

            if (identity != null)
            {
                // Set Authentication cookie
                FormsAuthentication.SetAuthCookie(identity.Name, 
                    loginControl.RememberMeSet);
                // Generate and Issue the Security Token
                ProcessRequest(identity);
            }
            else
            {
                return;
            }
        }
    }
}