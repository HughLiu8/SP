﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DevLeap.IPSTS
{
    public static class WSFederationConstants
    {
        public static class Actions
        {
            // Fields
            public const string Attribute = "wattr1.0";
            public const string Pseudonym = "wpseudo1.0";
            public const string SignIn = "wsignin1.0";
            public const string SignOut = "wsignout1.0";
            public const string SignOutCleanup = "wsignoutcleanup1.0";
        }
    }
}