﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue 

# https://sp2013-reference.accesscontrol.windows.net/FederationMetadata/2007-06/FederationMetadata.xml 
#	=> EntityDescriptor/RoleDescriptor/KeyDescriptor/KeyInfo/X509Data/X509Certificate

$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\SP2013DR\Ch-20-Claims-Fed-OAuth\ACS-Certificate.cer")
New-SPTrustedRootAuthority -Name "SP2013 ACS certificate" -Certificate $cert

$map0 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier" -IncomingClaimTypeDisplayName "NameIdentifier" -LocalClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/username"
$map1 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.microsoft.com/accesscontrolservice/2010/07/claims/identityprovider" -IncomingClaimTypeDisplayName "IdentityProvider" –SameAsIncoming
$map2 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress" -IncomingClaimTypeDisplayName "Email" -SameAsIncoming 

$realm = "http://claims.sp2013.local/_trust/default.aspx"
$signinurl = "https://sp2013-reference.accesscontrol.windows.net:443/v2/wsfederation"
$ip = New-SPTrustedIdentityTokenIssuer -Name "SP2013 ACS" -Description "SP2013 ACS" -Realm $realm -ImportTrustCertificate $cert -ClaimsMappings $map0,$map1,$map2 -SignInUrl $signinurl -IdentifierClaim $map0.InputClaimType

$ip
