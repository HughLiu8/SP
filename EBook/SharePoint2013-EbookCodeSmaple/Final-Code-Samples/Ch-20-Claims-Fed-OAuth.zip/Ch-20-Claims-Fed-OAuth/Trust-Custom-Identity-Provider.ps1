﻿Add-PSSnapin Microsoft.SharePoint.PowerShell -erroraction SilentlyContinue

$cert = New-Object System.Security.Cryptography.X509Certificates.X509Certificate2("C:\SP2013DR\Ch-20-Claims-Fed-OAuth\SP2013SRV01.sharepoint.local.cer")
New-SPTrustedRootAuthority -Name "DevLeap Sample IP/STS certificate" -Certificate $cert

$map0 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name" -IncomingClaimTypeDisplayName "Name" -SameAsIncoming 
$map1 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/emailaddress" -IncomingClaimTypeDisplayName "Email" -SameAsIncoming 
$map2 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.xmlsoap.org/ws/2005/05/identity/claims/gender" -IncomingClaimTypeDisplayName "Gender" -SameAsIncoming 
$map3 = New-SPClaimTypeMapping -IncomingClaimType "http://schemas.devleap.com/SampleIPSTS/claims/favoritecolor" -IncomingClaimTypeDisplayName "FavoriteColor" -SameAsIncoming 


$realm = "http://claims.sp2013.local/_trust/default.aspx"
$signinurl = "https://localhost:44334/Issue.aspx"
$ip = New-SPTrustedIdentityTokenIssuer -Name "DevLeap Sample IP/STS" -Description "DevLeap Sample IP/STS" -Realm $realm -ImportTrustCertificate $cert -ClaimsMappings $map1,$map2,$map3 -SignInUrl $signinurl -IdentifierClaim $map1.InputClaimType

$ip = Get-SPTrustedIdentityTokenIssuer -Identity "DevLeap Sample IP/STS"
$ip.SigningCertificate = $cert
$ip.Update()